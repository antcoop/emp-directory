import React from "react";
import Tab from "./Tab";

function NavTabs({ pages, currentPage, handlePageChange }) {
  return (
    <ul className="nav nav-tabs">
      {pages.map(page => <Tab page={page} currentPage={currentPage} handlePageChange={handlePageChange} />)}
    </ul>
  );
}

export default NavTabs;
