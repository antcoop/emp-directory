import Home from './Home';
import About from './About';
import Blog from './Blog';
import Contact from './Contact';
export default { Home, About, Blog, Contact };