import React from "react";
import NavItem from "./NavItem";
function NavTabs(props) {
  const { handlePageChange, currentPage, pages} = props;
  const data = { currentPage, handlePageChange };
  return (
    <ul className="nav nav-tabs">
      {pages.map(page => <NavItem key={page} page={page} {...data} /> )}
    </ul>
  );
}

export default NavTabs;
