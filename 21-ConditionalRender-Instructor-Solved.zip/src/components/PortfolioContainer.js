import React, { Component } from "react";
import NavTabs from './NavTabs';
import pageComponents from "./pages";

class Portfolio extends Component {
  state = { 
    currentPage: "Home", 
    pages: Object.keys(pageComponents)
  };

  handlePageChange = page => this.setState({ currentPage: page });
  
  renderPage = () => {
    const { currentPage } = this.state;
    const Page = pageComponents[currentPage];
    return <Page />;
  };

  renderTabs = () => {
    const { currentPage, pages } = this.state;
    return (
      <NavTabs
        pages={pages}
        currentPage={currentPage}
        handlePageChange={this.handlePageChange}
      />
    );
  }

  render() {
    return (
      <>
        {this.renderTabs()}
        {this.renderPage()}
      </>
    );
  }
}

export default Portfolio;
