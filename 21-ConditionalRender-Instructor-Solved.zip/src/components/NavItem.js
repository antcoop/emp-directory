import React from 'react';
import classNames from 'classnames';

function NavItem(props) {
  const { handlePageChange, currentPage, page } = props;
  const  className = classNames({
    "nav-link": true,
    "active": currentPage === page
  });

  return (
    <li className="nav-item">
      <a 
        href={`#${page.toLowerCase()}`} 
        onClick={() => handlePageChange(page)} 
        className={className}
      >
        {page}
      </a>
    </li>
  );
}

export default NavItem;