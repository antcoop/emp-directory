import React from "react";
import Math from "./Math";

// Calculator renders the Math component 4 times with different props
function Calculator() {
  return (
    <div>
      <Math num1={19} operator="+" num2={142} />
      <Math num1={42} operator="-" num2={17} />
      <Math num1={100} operator="*" num2={3} />
      <Math num1={96} operator="/" num2={4} />
    </div>
  );
}

export default Calculator;
