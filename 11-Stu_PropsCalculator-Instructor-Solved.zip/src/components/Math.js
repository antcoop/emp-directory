import React from "react";

// The Math function component accepts a props argument
function Math({ operator, num1, num2 }) {
  const fn = {
    "+": (a,b) => a + b,
    "-": (a,b) => a - b,
    "*": (a,b) => a * b,
    "/": (a,b) => a / b,
  };

  const value = fn[operator](num1, num2);

  // Return a span element containing the calculated value
  // Set the fontSize to the value in pixels
  return <p>{num1} {operator} {num2} = <span>{value}</span></p>;
}

export default Math;
