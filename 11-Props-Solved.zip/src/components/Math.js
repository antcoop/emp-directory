import React from 'react';
const calc = {
  "+": (a,b) => a + b,
  "-": (a,b) => a - b,
  "*": (a,b) => a * b,
  "/": (a,b) => a / b,
}
function Math(props) {
  const { num1, operator, num2} = props;
  return <div>{num1} {operator} {num2} = {calc[operator](num1, num2)}</div>;
} 

export default Math;