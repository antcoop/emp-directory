import React from "react";
import Calculator from "./components/Calculator";

function App() {
  return (
    <div className="container">
      <Calculator />
    </div>
  );
}

export default App;
