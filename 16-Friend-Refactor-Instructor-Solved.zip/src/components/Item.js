import React from 'react';

function Item() {
  const state = {
    count: 0
  };

  return <h1>Item: {state.count}</h1>;
};

export default Item;